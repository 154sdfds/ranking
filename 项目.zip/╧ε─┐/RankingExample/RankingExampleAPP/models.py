from django.db import models
import uuid
# Create your models here.
class UUIDField(models.CharField) :
    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = kwargs.get('max_length', 64 )
        kwargs['blank'] = True
        models.CharField.__init__(self, *args, **kwargs)

    def pre_save(self, model_instance, add):
        if add :
            value = str(uuid.uuid4())
            value = ''.join(value.split('-'))
            setattr(model_instance, self.attname, value)
            return value
        else:
            return super(models.CharField, self).pre_save(model_instance, add)

class ranking_table(models.Model):
    #用户编号
    usernumber = UUIDField(primary_key=True,max_length=32,verbose_name="编号")

    #排名
    ranking = models.IntegerField(blank=False,verbose_name="IP")

    #客户端
    client =  models.CharField(max_length=50,blank=False,verbose_name="客户端")

    #分数
    fraction = models.BigIntegerField(max_length=8,blank=False,verbose_name="分数")

    class Meta:
        managed = False
        db_table = 'ranking_table'