from django.shortcuts import render
from django.http.response import JsonResponse
from django.db import connection
from RankingExampleAPP.models import *
# Create your views here.


#用户查询分数
def SelUserFraction(request):
    pageLists =[]
    datas = {}
    #客户端
    client = request.POST.get("client")

    #页数
    pages = request.POST.get("pages")
    #查询条数
    number_bars = request.POST.get("number_bars")

    if int(pages) != 0:
        pages = (int(pages) - 1) * int(number_bars)
        number_bars = int(number_bars)
    #用户自己的分数
    user_data = ranking_table.objects.filter(client=client).values()
    #这是有分数的情况下
    if user_data.__len__() == 1:
        #排行榜数据
        cursor = connection.cursor()
        sql_total_data = 'SELECT * FROM ranking_table  order by ranking  limit %s,%s'%(pages,number_bars)
        cursor.execute(sql_total_data)
        total_data = cursor.fetchall()
        for a in total_data:
            pageLists.append({"usernumber":a[0],"ranking":a[1],"client":a[2],"fraction":a[3]})
        datas["pageLists"] = pageLists
        datas["userLists"] = list(user_data)
        return JsonResponse({"code": "200", "type": "Json", "datas": datas, "msg": "数据查询成功"})
    else:
        datas["userLists"] ={"ranking":"999+","client":client,"fraction":"0"}
        return JsonResponse({"code": "200", "type": "Json", "datas": datas, "msg": "数据查询成功"})


#用户上传分数
def AddUserFraction(request):
    datas = {}
    #客户端
    client = request.POST.get("client")

    #分数
    fraction = request.POST.get("fraction")

    """
    判断数据库中是否有用户分数属于，如果没有就进行添加，有就修改数据和排名
    """
    sel_user_ranking = ranking_table.objects.filter(client=client).values()

    #当数据库中没有用户分数 数据时
    if sel_user_ranking.__len__() == 0:
        #进行添加用户分数数据
        ranking_table.objects.create(ranking=0,client=client,fraction=fraction)

        #修改数据库中的排名
        Result = UpdUserFraction(fraction,client)
        return Result
    else:
        Result = UpdUserFraction(fraction, client)
        return Result





#修改用户排名
def UpdUserFraction(fraction,client):
    # 获取到分数小于用户的数据
    judge_data = ranking_table.objects.filter(fraction__lt=fraction).values().order_by('ranking')
    if judge_data.__len__() == 0:
        total_count = ranking_table.objects.all()
        ranking_table.objects.filter(client=client).update(ranking=int(total_count.__len__()) + int(1))
        return JsonResponse({"code": "200", "type": "Json", "datas": [], "msg": "数据修改成功"})
    # 判断第一条数据用户名等于 修改用户名的话 直接修改分数即可
    if judge_data[0]["client"] == client:
        ranking_table.objects.filter(client=client).update(fraction=fraction)
        return JsonResponse({"code": "200", "type": "Json", "datas": [], "msg": "数据修改成功"})
    else:
        # 排名
        ranking = judge_data[0]["ranking"]
        ranking_table.objects.filter(client=client).update(fraction=fraction, ranking=ranking)
        for a in judge_data:
            up_ranking = int(a["ranking"]) + int(1)
            ranking_table.objects.filter(client=a["client"]).update(ranking=up_ranking)
        return JsonResponse({"code": "200", "type": "Json", "datas": [], "msg": "数据修改成功"})
















    # if user_data.__len__() == 1:
    #     """
    #     判断数据库中的分数 是否小于上传的分数，如果小于则就不修改分数
    #     """
    #     #当上传的分数大于数据库里的分数时,进行分数修改并且改变排名
    #     if  int(fraction)>int(user_data[0]["fraction"]):
    #         # 获取到分数小于 用户分数的数据
    #         # sql_ranking_data = 'select * from ranking_table where fraction < %s' % (fraction)
    #         # cursor.execute(sql_ranking_data)
    #         # ranking_data = cursor.fetchall()
    #         # if ranking_data[0][1] == client:
    #         #     ranking_table.objects.filter()
    #         return JsonResponse({"code": "200", "type": "Json", "datas": "名次不做任何更改", "msg": "数据查询成功"})
    #     else:
    #         return JsonResponse({"code": "200", "type": "Json", "datas": "名次不做任何更改", "msg": "数据查询成功"})
    # else:
    #
    #      #排名
    #      ranking = 1
    #      #进行添加用户的分数数据，从而改变排名
    #      sel_data = "insert into ranking_table values(%s,%s,%s)"%(ranking,client,fraction);
    #      return JsonResponse({"code": "200", "type": "Json", "datas": "名次不做任何更改", "msg": "数据查询成功"})
    #
    #
    #
    #
    #      # 获取到分数小于 用户分数的数据
    #      sql_ranking_data = 'select * from ranking_table where fraction < %s' % (fraction)
    #      cursor.execute(sql_ranking_data)
    #      ranking_data = cursor.fetchall()
    #      # 排名
    #      ranking = ranking_data[0][0]
    #      sql_up_data = 'update ranking_table set fraction = %s,ranking=%s where client="%s" ' % (
    #      fraction, ranking, client)
    #      up_data = cursor.execute(sql_up_data)
    #      for a in ranking_data:
    #          print(a[1], a[0])
    #          # ranking_table.objects.filter(client=a[1]).update(ranking=int(a[0]) + int(1))
    #      return JsonResponse({"code": "200", "type": "Json", "datas": "名次不做任何更改", "msg": "数据查询成功"})