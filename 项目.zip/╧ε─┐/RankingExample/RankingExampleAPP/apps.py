from django.apps import AppConfig


class RankingexampleappConfig(AppConfig):
    name = 'RankingExampleAPP'
